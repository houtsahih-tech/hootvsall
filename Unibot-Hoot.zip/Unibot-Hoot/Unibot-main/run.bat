@echo off
echo ========================================
echo        Unibot Launcher
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python is not installed or not in PATH
    echo Please install Python from https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation
    pause
    exit /b 1
)

echo [+] Python found
echo.

REM Install required packages
echo [*] Installing dependencies...
pip install -r requirements.txt

if errorlevel 1 (
    echo Error: Failed to install dependencies
    pause
    exit /b 1
)

echo.
echo [+] Dependencies installed successfully
echo.
echo [*] Starting Unibot...
echo.

REM Run the main script
python src/main.py

if errorlevel 1 (
    echo.
    echo Error: Unibot exited with an error
    pause
    exit /b 1
)

pause
